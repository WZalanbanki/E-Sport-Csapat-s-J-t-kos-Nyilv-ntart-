class Jatekos{
    #nev;
    #fweapon;
    #fmap;
    #status;
    #kill;
    #death;
    #won;
    #lost;
    #totalgame;


    #hs;
    #kd;
    #winrate;

    constructor(nev, status, kill, death, won, lost, fweapon, fmap, totalgame){

    }

}