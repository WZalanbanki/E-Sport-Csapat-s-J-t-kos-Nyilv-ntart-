class Jatekos{
    #nev;
    #status;
    #kill;
    #death;
    #won;
    #lost;
    #totalgame;
    #team;

    #kd;
    #winrate;

    constructor(nev, status, team, kill, death, won, lost, totalgame){
        this.setNev(nev);
        this.setStatus(status);
        this.setTeam(team);
        this.setKill(kill);
        this.setDeath(death);
        this.setWon(won);
        this.setLost(lost);
        this.setTotalgame(totalgame);
        this.setKD(kd);
        this.setWinrate(winrate);
    }

    setNev(nev){
        this.#nev = nev;
    }
    setStatus(status){
        this.#status = status;
    }
    setTeam(team){
        this.#team = team;
    }
    setKill(kill){
        this.#kill = kill;
    }
    setDeath(death){
        this.#death = death;
    }
    setWon(won){
        this.#won = won;
    }
    setLost(lost){
        this.#lost = lost;
    }
    setTotalgame(totalgame){
        this.#totalgame = totalgame;
    }
    setKD(kd){
        this.#kd = kill/death;
    }
    setWinrate(winrate){
        this.#winrate = won/lost;
    }

    getNev(){
        return this.#nev;
    }
    getStatus(){
        return this.#status;
    }
    getTeam(){
        return this.#team;
    }
    getKill(){
        return this.#kill;
    }
    getDeath(){
        return this.#death;
    }
    getWon(){
        return this.#won;
    }
    getLost(){
        return this.#lost;
    }
    getTotalgame(){
        return this.#totalgame;
    }

}